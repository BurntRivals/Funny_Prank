# STUMBLE PARTY! (fan-made sibling prank page)

A colourful, mobile-first mini-event landing page with a playful fake "notification"
reveal. Fan-made parody — not affiliated with any game studio or Apple, and it
collects no data.

## Files
- `index.html` — the whole site
- `apple-icon.svg` — the icon shown in the notification

Keep both files together in the same folder.

## Host it free on GitHub Pages
1. Create a new GitHub repository.
2. Upload `index.html` and `apple-icon.svg` to the repository root.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, set **Source** to *Deploy from a branch*.
5. Choose the `main` branch and the `/ (root)` folder, then **Save**.
6. Wait a minute, then open the link GitHub shows (e.g. `https://yourname.github.io/your-repo/`).
